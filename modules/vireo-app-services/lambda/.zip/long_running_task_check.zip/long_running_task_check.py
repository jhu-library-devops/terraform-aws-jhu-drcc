"""
CloudWatch custom metric publisher: detects ECS tasks running longer than
a configurable threshold (default 24 hours) that were NOT started by an ECS
service (i.e. manually run tasks, scheduled tasks, CI/CD one-offs, etc.).

This Lambda is invoked on a daily schedule. It lists all running tasks in the
target ECS cluster, excludes those launched by a service (startedBy begins
with "ecs-svc/"), and publishes a custom CloudWatch metric with the count of
non-service tasks exceeding the age threshold.
"""

import os
import time
from datetime import datetime, timezone

import boto3

ECS_CLIENT = boto3.client("ecs")
CW_CLIENT = boto3.client("cloudwatch")

CLUSTER_ARN = os.environ["ECS_CLUSTER_ARN"]
THRESHOLD_HOURS = int(os.environ.get("THRESHOLD_HOURS", "24"))
METRIC_NAMESPACE = os.environ.get("METRIC_NAMESPACE", "Custom/ECS")
METRIC_NAME = os.environ.get("METRIC_NAME", "LongRunningNonServiceTaskCount")
ENVIRONMENT = os.environ.get("ENVIRONMENT", "unknown")


def handler(event, context):
    """Lambda entry point."""
    threshold_seconds = THRESHOLD_HOURS * 3600
    now = datetime.now(timezone.utc)

    long_running_count = 0
    task_arns = _list_all_running_tasks()

    # Describe tasks in batches of 100 (API limit)
    for i in range(0, len(task_arns), 100):
        batch = task_arns[i : i + 100]
        response = ECS_CLIENT.describe_tasks(cluster=CLUSTER_ARN, tasks=batch)

        for task in response.get("tasks", []):
            started_by = task.get("startedBy", "")
            # Skip tasks started by an ECS service — those are expected long-runners.
            if started_by.startswith("ecs-svc/"):
                continue

            started_at = task.get("startedAt")
            if started_at is None:
                continue

            age_seconds = (now - started_at).total_seconds()
            if age_seconds > threshold_seconds:
                long_running_count += 1
                task_id = task["taskArn"].split("/")[-1]
                service_name = task.get("group", "unknown").removeprefix("service:")
                print(
                    f"Long-running task: {task_id} "
                    f"(service={service_name}, "
                    f"age={age_seconds / 3600:.1f}h)"
                )

    # Publish the metric regardless of count so the alarm has data points
    CW_CLIENT.put_metric_data(
        Namespace=METRIC_NAMESPACE,
        MetricData=[
            {
                "MetricName": METRIC_NAME,
                "Value": long_running_count,
                "Unit": "Count",
                "Dimensions": [
                    {"Name": "ClusterArn", "Value": CLUSTER_ARN},
                    {"Name": "Environment", "Value": ENVIRONMENT},
                ],
            }
        ],
    )

    print(
        f"Published {METRIC_NAME}={long_running_count} "
        f"(cluster={CLUSTER_ARN}, threshold={THRESHOLD_HOURS}h)"
    )
    return {"longRunningTaskCount": long_running_count}


def _list_all_running_tasks():
    """Paginate through all RUNNING tasks in the cluster."""
    task_arns = []
    paginator = ECS_CLIENT.get_paginator("list_tasks")
    for page in paginator.paginate(
        cluster=CLUSTER_ARN, desiredStatus="RUNNING"
    ):
        task_arns.extend(page.get("taskArns", []))
    return task_arns
